import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';
import { useFonts, Poppins_400Regular, Poppins_600SemiBold, Poppins_700Bold } from '@expo-google-fonts/poppins';

export default function App() {
  const [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_600SemiBold,
    Poppins_700Bold,
  });


  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.headerBox}>
        <Image
          source={{ uri: 'https://cdn-icons-png.flaticon.com/128/4892/4892735.png' }}
          style={styles.profilePic}
        />
        <Text style={styles.header}>🌸 Student Profile 🌸</Text>
        <Text style={styles.subHeader}>Cavite State University</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>Name:</Text>
        <Text style={styles.info}>Mariz Nepomuceno</Text>

        <Text style={styles.label}>Age:</Text>
        <Text style={styles.info}>20</Text>

        <Text style={styles.label}>Course / Year / Section:</Text>
        <Text style={styles.info}>BS Computer Science / 3rd Year</Text>

        <Text style={styles.label}>💬About Me:</Text>
        <Text style={styles.info}>
          I’m a motivated computer science student passionate about
          mobile app development and designing clean, user-friendly interfaces.
        </Text>

        <Text style={styles.label}>🏆Achievements:</Text>
        <Text style={styles.info}>
          • Dean’s Lister 2024-2025{'\n'}
          • Created my first app using React Native{'\n'}
          • Member of the Programming Club
        </Text>

        <Text style={styles.label}>🪄Skills:</Text>
        <Text style={styles.info}>
          • JavaScript{'\n'}
          • Database{'\n'}
          • UI/UX Design{'\n'}
        </Text>
      </View>
      <Text style={styles.footerText}>
      🌷 “Keep growing and glowing.” 🌷
      </Text>
    </ScrollView>

  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#FFD6E8',
    paddingVertical: 30,
    paddingHorizontal: 20,
  },
  headerBox: {
    alignItems: 'center',
    marginBottom: 25,
    marginTop: -40,
    backgroundColor: '#FFB6C1', // light pink
    width: '100%',
    paddingVertical: 30,
    borderBottomLeftRadius: 50,
    borderBottomRightRadius: 50,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 5,
    elevation: 5,
  },
  profilePic: {
    width: 110,
    height: 110,
    borderRadius: 55,
    marginBottom: 10,
    borderWidth: 4,
    borderColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 10,
  },
  header: {
    fontSize: 28,
    fontFamily: 'Poppins_700Bold',
    color: '#fff',
  },
  subHeader: {
    fontSize: 16,
    fontFamily: 'Poppins_400Regular',
    color: '#fff',
    marginTop: 5,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    width: '100%',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 4,
    marginBottom: 20,
  },

  label: {
    fontSize: 18,
    fontFamily: 'Poppins_600SemiBold',
    color: '#FF69B4', // hot pink
    marginTop: 10,
  },
  info: {
    fontSize: 16,
    fontFamily: 'Poppins_400Regular',
    color: '#555',
    lineHeight: 22,
  },
  footerText: {
  fontSize: 14,
  color: '#555',
  marginTop: 20,
  fontFamily: 'Poppins_400Regular',
  textAlign: 'center',
},
});
